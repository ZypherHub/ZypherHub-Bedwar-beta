shared.RiseSave = 6872274481
if pcall(function() readfile("risesix/games/6872274481.lua") end) then
	loadstring(readfile("risesix/games/6872274481.lua"))()
end